import pandas as pd

df = pd.read_excel("MembersList_20260707_051515_updated.xlsx")
print("Columns in _updated Excel file:")
print(df.columns.tolist())
print(f"\nShape: {df.shape}")
print(f"\nFirst 5 rows:")
for col in df.columns:
    print(f"  {col}")
print()
print(df.head())
