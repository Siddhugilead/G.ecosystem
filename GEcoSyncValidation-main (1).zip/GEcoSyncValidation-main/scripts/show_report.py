import pandas as pd
from pathlib import Path

data_dir = Path("../excel_files/707")
report_file = data_dir / "#Membership_Validation_Report.xlsx"

# Read the Results sheet
df = pd.read_excel(report_file, sheet_name="Results")

# Display key columns for grouping 15898
print("=" * 150)
print("VALIDATION REPORT - GROUPING 15898")
print("=" * 150)

for row_idx, row in df.iterrows():
    print(f"\nGroupingID: {row['GroupingID']}")
    print(f"GroupName (Src): {row['GroupNameSrc']}")
    print(f"GroupName (O365): {row['GroupName0365']}")
    print()
    print(f"  STANDING:      Master={row['TeamSrc_Standing']:<3} | O365={row['O365_Standing']:<3}")
    print(f"  SITUATIONAL:   Master={row['TeamSrc_Situational']:<3} | O365={row['O365_Situational']:<3}")
    print(f"  INFORM:        Master={row['TeamSrc_Inform']:<3} | O365={row['O365_Inform']:<3}")
    print(f"  MAIN:          Master={row['TeamSrc_Main']:<3} | O365={row['O365_Main']:<3}")
    print()
    print(f"  MissingMain: {row['MissingMain']}")
    print(f"  ExtraMain: {row['ExtraMain']}")
    print(f"  Notes: {row['Notes']}")

