import pandas as pd

df = pd.read_csv("MembersList_20260707_051515.csv")
print("Columns in raw CSV:")
print(df.columns.tolist())
print(f"\nTotal rows: {len(df)}")
print(f"\nFirst 5 rows:")
print(df.head())
