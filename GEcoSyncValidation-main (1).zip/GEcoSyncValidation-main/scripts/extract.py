import argparse
import logging
import os
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

# 0-based column indexes in the source sheet
GROUP_MAIL_COL = 1
MEMBER_UPN_COL = 4
DESCRIPTION_COL = 5
GROUPING_ID_COL = 6

GROUPING_RE = re.compile(r"grouping(?:id)?\s*:\s*(\d+)", re.IGNORECASE)
PARENS_NUMBER_RE = re.compile(r"\((\d+)\)")
ROSTER_MEMBERS_RE = re.compile(r"roster\s+members\s+(\d+)", re.IGNORECASE)
REQUIRED_TYPES = {"Main", "Situational", "Standing"}


def setup_logging() -> None:
    """Log to console and a daily log file for auditability."""
    root_dir = Path(__file__).resolve().parent.parent
    log_dir = root_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"run_{datetime.now().strftime('%Y%m%d')}.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def load_env_file() -> dict[str, str]:
    """Load key=value pairs from .env (workspace root or script folder)."""
    script_dir = Path(__file__).resolve().parent
    candidates = [script_dir.parent / ".env", script_dir / ".env"]
    env_map: dict[str, str] = {}
    for env_path in candidates:
        if not env_path.exists():
            continue
        for line in env_path.read_text(encoding="utf-8").splitlines():
            raw = line.strip()
            if not raw or raw.startswith("#") or "=" not in raw:
                continue
            key, value = raw.split("=", 1)
            env_map[key.strip()] = value.strip().strip('"').strip("'")
        break
    return env_map


def env_value(name: str, default: str, env_map: dict[str, str]) -> str:
    """Environment variable value with .env fallback."""
    return os.getenv(name, env_map.get(name, default))


def is_mmdd_folder_name(name: str) -> bool:
    """True when folder name looks like MDD or MMDD and is a valid month/day."""
    if not name.isdigit() or len(name) not in (3, 4):
        return False

    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    if month < 1 or month > 12:
        return False
    if day < 1 or day > 31:
        return False

    try:
        datetime(datetime.now().year, month, day)
    except ValueError:
        return False
    return True


def mmdd_sort_key(name: str) -> tuple[int, int]:
    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    return month, day


def resolve_data_dir(env_map: dict[str, str]) -> Path:
    script_dir = Path(__file__).resolve().parent
    configured = env_value("DATA_DIR", "excel_files", env_map)
    candidate = Path(configured)
    if candidate.is_absolute():
        root_data_dir = candidate
    else:
        local = script_dir / configured
        root_data_dir = local if local.exists() else script_dir.parent / configured

    daily_folder = env_value("DAILY_FOLDER", "", env_map).strip()
    if daily_folder:
        forced_dir = root_data_dir / daily_folder
        if not forced_dir.exists():
            raise FileNotFoundError(f"DAILY_FOLDER not found under DATA_DIR: {forced_dir}")
        return forced_dir

    if not root_data_dir.exists() or not root_data_dir.is_dir():
        return root_data_dir

    dated_dirs = [
        p for p in root_data_dir.iterdir()
        if p.is_dir() and is_mmdd_folder_name(p.name)
    ]
    if not dated_dirs:
        return root_data_dir

    # Pick the latest day folder by MMDD value.
    return max(dated_dirs, key=lambda p: mmdd_sort_key(p.name))


def ensure_column(df: pd.DataFrame, col_index: int) -> pd.DataFrame:
    """Guarantee a column index exists so assignment is always safe."""
    while df.shape[1] <= col_index:
        df[df.shape[1]] = None
    return df


def safe_text(value: Any) -> str:
    """Normalize a value to clean lowercase text; NaN becomes empty string."""
    if pd.isna(value):
        return ""
    return str(value).strip().lower()


def extract_grouping_or_members(text: object) -> int | None:
    """
    Extract first numeric id from supported patterns:
    - grouping: 1234
    - groupingid: 1234
    - (1234)
    - roster members 1234
    """
    text_clean = safe_text(text).strip("() ")
    if not text_clean:
        return None

    for pattern in (GROUPING_RE, PARENS_NUMBER_RE, ROSTER_MEMBERS_RE):
        match = pattern.search(text_clean)
        if match:
            return int(match.group(1))
    return None


def classify_group_mail(mail: object) -> str | None:
    value = safe_text(mail)
    if not value:
        return None
    if "-situational@" in value:
        return "Situational"
    if "-standing@" in value:
        return "Standing"
    if "@" in value:
        return "Main"
    return None


def build_presence_map(rows: pd.DataFrame) -> dict[tuple[int, str], set[str]]:
    """Build map of (GroupingID, MemberUPN) -> set of group types seen."""
    presence: dict[tuple[int, str], set[str]] = defaultdict(set)
    for _, row in rows.iterrows():
        upn = safe_text(row[MEMBER_UPN_COL])
        grouping = row[GROUPING_ID_COL]
        group_type = classify_group_mail(row[GROUP_MAIL_COL])

        if not upn or pd.isna(grouping) or group_type is None:
            continue
        presence[(int(grouping), upn)].add(group_type)
    return presence


def process_file(input_path: Path, start_row: int = 2) -> Path:
    working_input = input_path
    if input_path.suffix.lower() == ".csv":
        # Convert CSV source to Excel first, then run standard extraction flow.
        csv_df = pd.read_csv(input_path, header=None, encoding="utf-8-sig")
        working_input = input_path.with_suffix(".xlsx")
        csv_df.to_excel(working_input, index=False, header=False)

    df = pd.read_excel(working_input, header=None)
    if df.empty:
        raise ValueError(f"Input file has no rows: {working_input}")

    required_indexes = [GROUP_MAIL_COL, MEMBER_UPN_COL, DESCRIPTION_COL]
    max_required = max(required_indexes)
    if df.shape[1] <= max_required:
        raise ValueError(
            f"Input must contain at least {max_required + 1} columns. Found {df.shape[1]} in {working_input}"
        )

    ensure_column(df, GROUPING_ID_COL)

    # Keep source layout but ensure expected header text in row 1.
    df.at[0, GROUPING_ID_COL] = "GroupingID"

    start_index = max(start_row - 1, 0)
    rows = df.iloc[start_index:].copy()

    rows[DESCRIPTION_COL] = rows[DESCRIPTION_COL].map(safe_text)
    rows[GROUPING_ID_COL] = rows[DESCRIPTION_COL].map(extract_grouping_or_members)

    # Delete records where GroupingID is blank.
    rows = rows[rows[GROUPING_ID_COL].notna()].copy()

    presence = build_presence_map(rows)
    exists_in_all_three = []
    for _, row in rows.iterrows():
        upn = safe_text(row[MEMBER_UPN_COL])
        grouping = row[GROUPING_ID_COL]
        if not upn or pd.isna(grouping):
            exists_in_all_three.append("No")
            continue

        key = (int(grouping), upn)
        exists_in_all_three.append("Yes" if presence.get(key, set()) >= REQUIRED_TYPES else "No")

    rows["ExistsInAll3"] = exists_in_all_three

    # Rebuild output with preserved top rows and filtered data rows.
    output_df = pd.concat([df.iloc[:start_index].copy(), rows], ignore_index=True)
    output_df.at[0, GROUPING_ID_COL] = "GroupingID"
    output_df.at[0, "ExistsInAll3"] = "ExistsInAll3"

    # Always save next to input workbook.
    output_path = working_input.with_name(f"{working_input.stem}_updated.xlsx")
    output_df.to_excel(output_path, index=False, header=False)
    return output_path


def resolve_default_input() -> Path:
    """Resolve daily O365 input with priority: MembersList CSV/XLSX, then other source files."""
    env_map = load_env_file()
    data_dir = resolve_data_dir(env_map)
    configured_input = env_value("MEMBER_LIST_FILE", "", env_map)
    if not configured_input:
        configured_input = env_value("EXTRACT_INPUT_FILE", "", env_map)
    if configured_input:
        configured_path = Path(configured_input)
        if not configured_path.is_absolute():
            configured_path = data_dir / configured_path
        if configured_path.exists():
            return configured_path

    search_dirs = [
        data_dir,
        Path.cwd(),
    ]

    def preferred_matches(directory: Path) -> list[Path]:
        files = [p for p in directory.iterdir() if p.is_file()]
        lower_name = lambda p: p.name.lower()

        # Highest priority: MembersList CSV files (latest by name), then MembersList XLSX.
        members_csv = sorted([p for p in files if lower_name(p).startswith("memberslist_") and p.suffix.lower() == ".csv"])
        if members_csv:
            return members_csv

        members_xlsx = sorted([p for p in files if lower_name(p).startswith("memberslist_") and p.suffix.lower() == ".xlsx"])
        if members_xlsx:
            return members_xlsx

        # Fallback: any non-output, non-master xlsx.
        return sorted([
            p for p in files
            if p.suffix.lower() == ".xlsx"
            and "_updated" not in lower_name(p)
            and "membership_validation_report" not in lower_name(p)
            and "teamsrc" not in lower_name(p)
        ])

    for directory in search_dirs:
        if not directory.exists():
            continue
        matches = preferred_matches(directory)
        if matches:
            return matches[-1]

    raise FileNotFoundError("No input source found in excel_files/current folder. Pass one with --file.")


def main() -> None:
    setup_logging()
    env_map = load_env_file()
    default_start_row = int(env_value("EXTRACT_START_ROW", "2", env_map))

    parser = argparse.ArgumentParser(description="Extract GroupingID and flag ExistsInAll3")
    parser.add_argument("--file", type=str, default=None, help="Input Excel file path")
    parser.add_argument("--start-row", type=int, default=default_start_row, help="1-based row number to start processing")
    args = parser.parse_args()

    input_path = Path(args.file) if args.file else resolve_default_input()
    logging.info("Extract input resolved to: %s", input_path)
    output_path = process_file(input_path, start_row=args.start_row)
    logging.info("Extract output created: %s", output_path)

    print(f"Numbers written to column index {GROUPING_ID_COL}.")
    print(f"ExistsInAll3 added successfully. Output: {output_path}")


if __name__ == "__main__":
    main()
