import os
import sys
from datetime import datetime
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent


def load_env_file() -> dict[str, str]:
    env_path = ROOT_DIR / ".env"
    env_map: dict[str, str] = {}
    if not env_path.exists():
        return env_map

    for line in env_path.read_text(encoding="utf-8").splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#") or "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        env_map[key.strip()] = value.strip().strip('"').strip("'")
    return env_map


def env_value(name: str, default: str, env_map: dict[str, str]) -> str:
    return os.getenv(name, env_map.get(name, default))


def resolve_root_data_dir(env_map: dict[str, str]) -> Path:
    configured = env_value("DATA_DIR", "excel_files", env_map)
    candidate = Path(configured)
    if candidate.is_absolute():
        return candidate

    local = SCRIPT_DIR / configured
    if local.exists():
        return local
    return ROOT_DIR / configured


def is_mmdd_folder_name(name: str) -> bool:
    """True when folder name looks like MDD or MMDD and is a valid month/day."""
    if not name.isdigit() or len(name) not in (3, 4):
        return False

    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    if month < 1 or month > 12:
        return False
    if day < 1 or day > 31:
        return False

    try:
        datetime(datetime.now().year, month, day)
    except ValueError:
        return False
    return True


def mmdd_sort_key(name: str) -> tuple[int, int]:
    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    return month, day


def resolve_data_dir(env_map: dict[str, str]) -> Path:
    root_data_dir = resolve_root_data_dir(env_map)

    daily_folder = env_value("DAILY_FOLDER", "", env_map).strip()
    if daily_folder:
        forced_dir = root_data_dir / daily_folder
        if not forced_dir.exists():
            raise FileNotFoundError(f"DAILY_FOLDER not found under DATA_DIR: {forced_dir}")
        return forced_dir

    if not root_data_dir.exists() or not root_data_dir.is_dir():
        return root_data_dir

    dated_dirs = [
        p for p in root_data_dir.iterdir()
        if p.is_dir() and is_mmdd_folder_name(p.name)
    ]
    if not dated_dirs:
        return root_data_dir

    return max(dated_dirs, key=lambda p: mmdd_sort_key(p.name))


def resolve_member_file(data_dir: Path, configured: str) -> Path | None:
    if configured:
        configured_path = Path(configured)
        if configured_path.is_absolute() and configured_path.exists():
            return configured_path

        candidate = data_dir / configured_path
        if candidate.exists():
            return candidate

    candidates = sorted(data_dir.glob("MembersList_*.csv"))
    if candidates:
        return candidates[-1]

    candidates = sorted(data_dir.glob("MembersList_*.xlsx"))
    if candidates:
        return candidates[-1]
    return None


def resolve_master_file(data_dir: Path, root_data_dir: Path, configured: str) -> Path:
    configured_path = Path(configured) if configured else Path("TeamSrc.xlsx")
    if configured and configured_path.is_absolute():
        return configured_path

    if configured:
        daily_candidate = data_dir / configured_path
        if daily_candidate.exists():
            return daily_candidate

        root_candidate = root_data_dir / configured_path
        if root_candidate.exists():
            return root_candidate

    daily_matches = sorted(data_dir.glob("TeamSrc*.xlsx"))
    if daily_matches:
        return daily_matches[-1]

    root_matches = sorted(root_data_dir.glob("TeamSrc*.xlsx"))
    if root_matches:
        return root_matches[-1]

    return data_dir / configured_path


def main() -> None:
    env_map = load_env_file()
    required_keys = ["MASTER_FILE", "REPORT_FILE"]

    missing_keys = [k for k in required_keys if not env_value(k, "", env_map)]
    if missing_keys:
        print(f"FAIL: Missing required .env keys: {missing_keys}")
        sys.exit(1)

    data_dir = resolve_data_dir(env_map)
    root_data_dir = resolve_root_data_dir(env_map)
    if not data_dir.exists():
        print(f"FAIL: DATA_DIR does not exist: {data_dir}")
        sys.exit(1)

    script_files = [
        SCRIPT_DIR / "extract.py",
        SCRIPT_DIR / "validate.py",
        SCRIPT_DIR / "menu.py",
    ]
    missing_scripts = [str(p) for p in script_files if not p.exists()]
    if missing_scripts:
        print(f"FAIL: Missing script files: {missing_scripts}")
        sys.exit(1)

    member_file = resolve_member_file(data_dir, env_value("MEMBER_LIST_FILE", "", env_map))
    master_file = resolve_master_file(data_dir, root_data_dir, env_value("MASTER_FILE", "", env_map))

    missing_inputs = []
    if member_file is None:
        missing_inputs.append(f"MembersList_*.csv or MembersList_*.xlsx in {data_dir}")
    if not master_file.exists():
        missing_inputs.append(str(master_file))
    if missing_inputs:
        print(f"FAIL: Missing input files: {missing_inputs}")
        sys.exit(1)

    print("PASS: Smoke test checks succeeded.")
    print(f"DATA_DIR: {data_dir}")
    print(f"MEMBER_LIST_FILE: {member_file.name}")
    print(f"MASTER_FILE: {master_file.name}")


if __name__ == "__main__":
    main()
