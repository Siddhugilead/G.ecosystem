import pandas as pd
from pathlib import Path

# Load O365 file
data_dir = Path("../excel_files/707")
validation_file = data_dir / "MembersList_20260707_051515_updated.xlsx"

df = pd.read_excel(validation_file)

# Filter for grouping 15898
df_15898 = df[df['GroupingID'].astype(str).str.strip() == '15898'].copy()

print("=" * 100)
print(f"TOTAL ROWS FOR GROUPING 15898: {len(df_15898)}")
print("=" * 100)

# Normalize emails
def normalize_email(email):
    if pd.isna(email):
        return ""
    email = str(email).lower().strip()
    if "@gc.com" in email:
        email = email.replace("@gc.com", "@gilead.com")
    if "@gileadconnect.onmicrosoft.com" in email:
        email = email.replace("@gileadconnect.onmicrosoft.com", "@gilead.com")
    return email

df_15898['MemberMail_norm'] = df_15898['MemberMail'].apply(normalize_email)
df_15898['GroupName_lower'] = df_15898['GroupName'].astype(str).str.lower()

# Show all rows
print("\nAll O365 rows for grouping 15898:")
print("-" * 100)
for idx, row in df_15898.iterrows():
    group_name = row['GroupName_lower']
    has_standing = 'standing' in group_name
    has_situational = 'situational' in group_name
    has_inform = 'inform' in group_name or 'information' in group_name
    classification = []
    if has_standing:
        classification.append("STANDING")
    if has_situational:
        classification.append("SITUATIONAL")
    if has_inform:
        classification.append("INFORM")
    if not classification:
        classification.append("UNCLASSIFIED/MAIN")
    
    print(f"{row['MemberMail_norm']:<35} | {group_name:<40} | {', '.join(classification)}")

# Count by classification
print("\n" + "=" * 100)
print("SUMMARY COUNT BY CLASSIFICATION:")
print("=" * 100)

standing = set()
situational = set()
inform = set()
main_pure = set()

for idx, row in df_15898.iterrows():
    email = row['MemberMail_norm']
    if not email or 'noreply' in email:
        continue
    
    group_name = row['GroupName_lower']
    
    if 'standing' in group_name:
        standing.add(email)
    if 'situational' in group_name:
        situational.add(email)
    if 'inform' in group_name or 'information' in group_name:
        inform.add(email)
    
    # Check if unclassified
    has_keyword = ('standing' in group_name or 'situational' in group_name or 
                   'inform' in group_name or 'information' in group_name)
    if not has_keyword:
        main_pure.add(email)

print(f"Standing only: {len(standing)} users")
print(f"  {sorted(standing)}\n")

print(f"Situational only: {len(situational)} users")
print(f"  {sorted(situational)}\n")

print(f"Inform: {len(inform)} users")
print(f"  {sorted(inform)}\n")

print(f"Pure Main (unclassified): {len(main_pure)} users")
print(f"  {sorted(main_pure)}\n")

# Calculate Main as union
main_union = standing | situational
print(f"Main (Standing ∪ Situational): {len(main_union)} users")
print(f"  {sorted(main_union)}\n")

# All Main including pure
all_main = standing | situational | main_pure
print(f"ALL Main users (Standing ∪ Situational ∪ Pure): {len(all_main)} users")
print(f"  {sorted(all_main)}\n")
