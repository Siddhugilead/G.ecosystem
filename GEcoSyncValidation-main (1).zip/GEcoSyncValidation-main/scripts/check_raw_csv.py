import pandas as pd
from pathlib import Path

data_dir = Path(".")
csv_file = data_dir / "MembersList_20260707_051515.csv"

# Read raw CSV
df = pd.read_csv(csv_file)

print("=" * 100)
print("RAW CSV FILE - GROUPING 15898 - ALL ROWS")
print("=" * 100)

df_15898 = df[df['GroupingID'].astype(str).str.strip() == '15898'].copy()

print(f"\nTotal rows for grouping 15898: {len(df_15898)}\n")
print(f"{'Email':<35} | {'GroupMail':<50} | {'Description (first 50 chars)':<50}")
print("-" * 140)

for idx, row in df_15898.iterrows():
    email = str(row['Email']).lower()
    group_mail = str(row['GroupMail']).lower() if 'GroupMail' in df.columns and row['GroupMail'] else "N/A"
    desc = str(row['Description'])[:50] if 'Description' in df.columns else "N/A"
    print(f"{email:<35} | {group_mail:<50} | {desc:<50}")

print("\n" + "=" * 100)
print("BREAKDOWN BY GROUP CLASSIFICATION")
print("=" * 100)

# Count by GroupMail classification
if 'GroupMail' in df.columns:
    for idx, row in df_15898.iterrows():
        group_mail = str(row['GroupMail']).lower()
        is_standing = '-standing@' in group_mail
        is_situational = '-situational@' in group_mail
        is_inform = '-inform@' in group_mail or '-information@' in group_mail
        is_main = '@' in group_mail and not is_standing and not is_situational and not is_inform
        
        classification = []
        if is_standing:
            classification.append("STANDING")
        if is_situational:
            classification.append("SITUATIONAL")
        if is_inform:
            classification.append("INFORM")
        if is_main:
            classification.append("MAIN")
        if not classification:
            classification.append("UNCLASSIFIED")
        
        print(f"{str(row['Email']).lower():<35} | {group_mail:<50} | {', '.join(classification)}")
