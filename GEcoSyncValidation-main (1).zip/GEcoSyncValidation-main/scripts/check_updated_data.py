import pandas as pd

df = pd.read_excel("MembersList_20260707_051515_updated.xlsx")

print("=" * 100)
print("ALL ROWS IN _UPDATED FILE")
print("=" * 100)

print(f"{'MemberMail':<35} | {'GroupName':<40} | {'GroupingID':<15}")
print("-" * 92)

for idx, row in df.iterrows():
    email = str(row['MemberMail']).lower()
    group_name = str(row['GroupName']).lower()
    grouping_id = row['GroupingID']
    if pd.isna(grouping_id):
        grouping_id = "EMPTY"
    print(f"{email:<35} | {group_name:<40} | {str(grouping_id):<15}")

print("\n" + "=" * 100)
print("GROUP CLASSIFICATION COUNT")
print("=" * 100)

# Count by GroupingID and GroupName classification
classified = {'Standing': [], 'Situational': [], 'Inform': [], 'Main': [], 'NoGroupingID': []}

for idx, row in df.iterrows():
    group_name = str(row['GroupName']).lower()
    grouping_id = row['GroupingID']
    
    if pd.isna(grouping_id):
        classified['NoGroupingID'].append(str(row['MemberMail']))
    elif 'standing' in group_name:
        classified['Standing'].append(str(row['MemberMail']))
    elif 'situational' in group_name:
        classified['Situational'].append(str(row['MemberMail']))
    elif 'inform' in group_name or 'information' in group_name:
        classified['Inform'].append(str(row['MemberMail']))
    else:
        classified['Main'].append(str(row['MemberMail']))

for cat, users in classified.items():
    print(f"{cat}: {len(users)} users")
    if users:
        for user in sorted(users):
            print(f"  - {user}")
