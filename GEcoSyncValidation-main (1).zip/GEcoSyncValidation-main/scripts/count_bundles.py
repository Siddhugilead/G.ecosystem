import pandas as pd
from pathlib import Path
from collections import defaultdict

# Paths
data_dir = Path("../excel_files/707")
master_file = data_dir / "TeamSrc707.xlsx"
validation_file = data_dir / "MembersList_20260707_051515_updated.xlsx"

# Load files
df_master = pd.read_excel(master_file)
df_validation = pd.read_excel(validation_file)

# Normalize emails
def normalize_email(email):
    if pd.isna(email):
        return ""
    email = str(email).lower().strip()
    if "@gc.com" in email:
        email = email.replace("@gc.com", "@gilead.com")
    if "@gileadconnect.onmicrosoft.com" in email:
        email = email.replace("@gileadconnect.onmicrosoft.com", "@gilead.com")
    return email

# Master file processing
print("=" * 100)
print("MASTER FILE (TeamSrc707.xlsx) - BUNDLE COUNTS BY GROUPING ID")
print("=" * 100)

master_counts = defaultdict(lambda: {'Standing': 0, 'Situational': 0, 'Inform': 0, 'Main': set(), 'PureMain': set()})

for _, row in df_master.iterrows():
    email = normalize_email(row['Email'])
    if not email or "noreply" in email:
        continue
    
    grouping_id = str(row['GroupingID']).strip()
    bundle_name = str(row['BundleName']).lower().strip()
    
    classified = False
    if 'standing' in bundle_name:
        master_counts[grouping_id]['Standing'] += 1
        master_counts[grouping_id]['Main'].add(email)
        classified = True
    if 'situational' in bundle_name:
        master_counts[grouping_id]['Situational'] += 1
        master_counts[grouping_id]['Main'].add(email)
        classified = True
    if 'inform' in bundle_name or 'information' in bundle_name:
        master_counts[grouping_id]['Inform'] += 1
        classified = True
    
    if not classified:
        master_counts[grouping_id]['PureMain'].add(email)

print(f"{'GroupingID':<12} {'Standing':<12} {'Situational':<12} {'Inform':<12} {'Main':<12} {'PureMain':<12}")
print("-" * 72)
for gid in sorted(master_counts.keys()):
    main_count = len(master_counts[gid]['Main'])
    pure_main_count = len(master_counts[gid]['PureMain'])
    print(f"{gid:<12} {master_counts[gid]['Standing']:<12} {master_counts[gid]['Situational']:<12} {master_counts[gid]['Inform']:<12} {main_count:<12} {pure_main_count:<12}")

# Validation file processing
print("\n" + "=" * 100)
print("VALIDATION FILE (MembersList_*_updated.xlsx) - BUNDLE COUNTS BY GROUPING ID")
print("=" * 100)

val_counts = defaultdict(lambda: {'Standing': 0, 'Situational': 0, 'Inform': 0, 'Main': set(), 'PureMain': set()})

for _, row in df_validation.iterrows():
    email = normalize_email(row['MemberMail']) if row['MemberMail'] else normalize_email(row['MemberUPN'])
    if not email or "noreply" in email:
        continue
    
    grouping_id = str(row['GroupingID']).strip()
    group_name = str(row['GroupName']).lower()
    
    classified = False
    if 'standing' in group_name:
        val_counts[grouping_id]['Standing'] += 1
        val_counts[grouping_id]['Main'].add(email)
        classified = True
    if 'situational' in group_name:
        val_counts[grouping_id]['Situational'] += 1
        val_counts[grouping_id]['Main'].add(email)
        classified = True
    if 'inform' in group_name or 'information' in group_name:
        val_counts[grouping_id]['Inform'] += 1
        classified = True
    
    if not classified:
        val_counts[grouping_id]['PureMain'].add(email)

print(f"{'GroupingID':<12} {'Standing':<12} {'Situational':<12} {'Inform':<12} {'Main':<12} {'PureMain':<12}")
print("-" * 72)
for gid in sorted(val_counts.keys()):
    main_count = len(val_counts[gid]['Main'])
    pure_main_count = len(val_counts[gid]['PureMain'])
    print(f"{gid:<12} {val_counts[gid]['Standing']:<12} {val_counts[gid]['Situational']:<12} {val_counts[gid]['Inform']:<12} {main_count:<12} {pure_main_count:<12}")

# Summary comparison
print("\n" + "=" * 100)
print("COMPARISON - DISCREPANCIES BY BUNDLE")
print("=" * 100)
print(f"{'GroupingID':<12} {'Bundle':<15} {'Master':<10} {'O365':<10} {'Diff':<10}")
print("-" * 60)

all_groups = set(master_counts.keys()) | set(val_counts.keys())
for gid in sorted(all_groups):
    for bundle in ['Standing', 'Situational', 'Inform', 'Main', 'PureMain']:
        if bundle == 'Main':
            master_val = len(master_counts[gid]['Main'])
            o365_val = len(val_counts[gid]['Main'])
        elif bundle == 'PureMain':
            master_val = len(master_counts[gid]['PureMain'])
            o365_val = len(val_counts[gid]['PureMain'])
        else:
            master_val = master_counts[gid][bundle]
            o365_val = val_counts[gid][bundle]
        
        diff = o365_val - master_val
        
        marker = " *** MISMATCH ***" if diff != 0 else ""
        print(f"{gid:<12} {bundle:<15} {master_val:<10} {o365_val:<10} {diff:<10}{marker}")

