import pandas as pd
from collections import defaultdict
from datetime import datetime
import logging
import os
from pathlib import Path
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

IRDT_SCHEMA_ID = "38"
IRDT_BUNDLES = {
    "coreworkinggroup": ("CoreWG", "CoreWG"),
    "strategicframeworkworkinggroup": ("StrategicWG", "StrategicWG"),
    "dataneedsworkinggroup": ("DataWG", "DataWG"),
    "irwgstanding": ("IRWG-Standing", "IRWG-Standing"),
    "irwgsituational": ("IRWG-Situational", "IRWG-Situational"),
    "dgseditor": ("DGS", "DGS"),
}

def setup_logging() -> None:
    """Log to console and a daily log file for auditability."""
    root_dir = Path(__file__).resolve().parent.parent
    log_dir = root_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"run_{datetime.now().strftime('%Y%m%d')}.log"

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def load_env_file() -> dict[str, str]:
    """Load key=value pairs from .env (workspace root or script folder)."""
    script_dir = Path(__file__).resolve().parent
    candidates = [script_dir.parent / ".env", script_dir / ".env"]
    env_map: dict[str, str] = {}
    for env_path in candidates:
        if not env_path.exists():
            continue
        for line in env_path.read_text(encoding="utf-8").splitlines():
            raw = line.strip()
            if not raw or raw.startswith("#") or "=" not in raw:
                continue
            key, value = raw.split("=", 1)
            env_map[key.strip()] = value.strip().strip('"').strip("'")
        break
    return env_map


def env_value(name: str, default: str, env_map: dict[str, str]) -> str:
    """Environment variable value with .env fallback."""
    return os.getenv(name, env_map.get(name, default))


def resolve_root_data_dir(env_map: dict[str, str]) -> Path:
    script_dir = Path(__file__).resolve().parent
    configured = env_value("DATA_DIR", "excel_files", env_map)
    candidate = Path(configured)
    if candidate.is_absolute():
        return candidate

    local = script_dir / configured
    if local.exists():
        return local
    return script_dir.parent / configured


def is_mmdd_folder_name(name: str) -> bool:
    """True when folder name looks like MDD or MMDD and is a valid month/day."""
    if not name.isdigit() or len(name) not in (3, 4):
        return False

    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    if month < 1 or month > 12:
        return False
    if day < 1 or day > 31:
        return False

    try:
        datetime(datetime.now().year, month, day)
    except ValueError:
        return False
    return True


def mmdd_sort_key(name: str) -> tuple[int, int]:
    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    return month, day


def resolve_data_dir(env_map: dict[str, str]) -> Path:
    root_data_dir = resolve_root_data_dir(env_map)

    daily_folder = env_value("DAILY_FOLDER", "", env_map).strip()
    if daily_folder:
        forced_dir = root_data_dir / daily_folder
        if not forced_dir.exists():
            raise FileNotFoundError(f"DAILY_FOLDER not found under DATA_DIR: {forced_dir}")
        return forced_dir

    if not root_data_dir.exists() or not root_data_dir.is_dir():
        return root_data_dir

    dated_dirs = [
        p for p in root_data_dir.iterdir()
        if p.is_dir() and is_mmdd_folder_name(p.name)
    ]
    if not dated_dirs:
        return root_data_dir

    # Pick the latest day folder by MMDD value.
    return max(dated_dirs, key=lambda p: mmdd_sort_key(p.name))


def resolve_master_file(data_dir: Path, root_data_dir: Path, file_name: str) -> Path:
    configured_path = Path(file_name)
    if configured_path.is_absolute():
        return configured_path

    if file_name:
        daily_candidate = data_dir / configured_path
        if daily_candidate.exists():
            return daily_candidate

        root_candidate = root_data_dir / configured_path
        if root_candidate.exists():
            return root_candidate

    daily_matches = sorted(data_dir.glob("TeamSrc*.xlsx"))
    if daily_matches:
        return daily_matches[-1]

    root_matches = sorted(root_data_dir.glob("TeamSrc*.xlsx"))
    if root_matches:
        return root_matches[-1]

    # Fall back to configured path for clear error messaging upstream.
    return (data_dir / configured_path) if file_name else (data_dir / "TeamSrc.xlsx")


def ensure_columns(df, required_columns, file_path):
    """Fail fast with a clear message when expected columns are missing."""
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns in {file_path}: {missing}")


def normalize_schema_id(value):
    """Normalize numeric Excel schema identifiers without changing nonnumeric values."""
    text = str(value).strip()
    return text[:-2] if text.endswith(".0") else text


def normalize_bundle_name(value):
    """Normalize bundle labels so spaces and punctuation do not affect IRDT matching."""
    return "".join(char for char in str(value).lower() if char.isalnum())


def normalize_dl_address(value):
    """Normalize a DL address or display value for exact O365-to-TeamSource matching."""
    text = str(value).lower().strip().replace("/", " ")
    text = text.replace("(", "").replace(")", "")
    return "-".join(text.split())


def normalize_roster_stem(value):
    """Convert a roster name to the hyphenated stem used by O365 DL display names."""
    text = str(value).lower().replace("/", " ")
    text = text.replace("(", "").replace(")", "")
    return "-".join(text.split())


def build_irdt_maps(master_df, validation_df):
    """Build SchemaID 38 source and O365 membership maps keyed by GroupingID and IRDT bundle."""
    master_map = defaultdict(lambda: defaultdict(set))
    validation_map = defaultdict(lambda: defaultdict(set))
    expected_dl_map = defaultdict(dict)
    roster_ids = defaultdict(set)

    for _, row in master_df.iterrows():
        if normalize_schema_id(row['SchemaID']) != IRDT_SCHEMA_ID:
            continue

        group_id = row['GroupingID']
        roster_stem = normalize_roster_stem(row['GroupName'])
        bundle = IRDT_BUNDLES.get(normalize_bundle_name(row['BundleName']))
        roster_ids[roster_stem].add(group_id)
        if bundle is None:
            logging.warning(
                "Unmapped IRDT BundleName for GroupingID %s: %s",
                group_id,
                row['BundleName'],
            )
            continue

        bundle_key, suffix = bundle
        dl_stem = f"{roster_stem}-{suffix.lower()}"
        expected_dl_map[group_id][bundle_key] = f"{dl_stem}@gilead.com"
        email = row['MemberMail']
        if email and "noreply" not in email:
            master_map[group_id][bundle_key].add(email)

    duplicate_rosters = {
        roster_stem: sorted(group_ids)
        for roster_stem, group_ids in roster_ids.items()
        if len(group_ids) > 1
    }
    if duplicate_rosters:
        duplicate_text = "; ".join(
            f"{roster_stem} ({', '.join(group_ids)})"
            for roster_stem, group_ids in sorted(duplicate_rosters.items())
        )
        raise ValueError(f"SchemaID 38 roster names must be unique: {duplicate_text}")

    expected_lookup = {}
    for group_id, bundles in expected_dl_map.items():
        for bundle_key, address in bundles.items():
            dl_stem = address.removesuffix("@gilead.com")
            expected_lookup[dl_stem] = (group_id, bundle_key)
            expected_lookup[address] = (group_id, bundle_key)
    for _, row in validation_df.iterrows():
        mail = row['MemberMail']
        if not mail or "noreply" in str(mail):
            continue
        email = mail

        group_name = normalize_dl_address(row['GroupName'])
        match = expected_lookup.get(group_name)
        if match is None:
            continue
        group_id, bundle_key = match
        validation_map[group_id][bundle_key].add(email)

    return master_map, validation_map, expected_dl_map

def load_and_normalize(file_path, is_master=False):
    """Load and normalize data from Excel file"""
    try:
        df = pd.read_excel(file_path)
        logging.info(f"Successfully loaded {len(df)} rows from {file_path}")
    except Exception as e:
        logging.error(f"Error loading {file_path}: {str(e)}")
        raise

    if df.empty:
        raise ValueError(f"Input file has no rows: {file_path}")
    
    # Normalize emails
    def normalize_email(email):
        if pd.isna(email):
            return ""
        email = str(email).lower().strip()
        # Standardize all Gilead domains to @gilead.com
        if "@gc.com" in email:
            email = email.replace("@gc.com", "@gilead.com")
        if "@gileadconnect.onmicrosoft.com" in email:
            email = email.replace("@gileadconnect.onmicrosoft.com", "@gilead.com")
        return email
    
    if is_master:
        # Standardize source column names before any comparisons.
        df = df.rename(columns={
            'TeamRosterDisplayName': 'GroupName',
            'UserName': 'MemberName',
            'Email': 'MemberMail'
        })

        ensure_columns(df, ['MemberMail', 'GroupingID', 'BundleName', 'GroupName', 'SchemaID'], file_path)

        df['MemberMail'] = df['MemberMail'].apply(normalize_email)
        df['GroupingID'] = df['GroupingID'].astype(str).str.strip()
    else:
        ensure_columns(df, ['MemberMail', 'MemberUPN', 'GroupingID', 'GroupName'], file_path)

        df['MemberMail'] = df['MemberMail'].apply(normalize_email)
        df['MemberUPN'] = df['MemberUPN'].apply(normalize_email)
        df['GroupingID'] = df['GroupingID'].astype(str).str.strip()
    
    return df

def build_membership_maps(df, is_master=False):
    """Build membership maps from dataframe"""
    group_map = defaultdict(lambda: {'Standing': set(), 'Situational': set(), 'Inform': set(), 'Main': set()})
    
    if is_master:
        for _, row in df.iterrows():
            email = row['MemberMail']
            if not email or "noreply" in email:
                continue

            grouping_id = row['GroupingID']
            bundle_name = str(row['BundleName']).lower().strip()
            classified = False
            
            if 'standing' in bundle_name:
                group_map[grouping_id]['Standing'].add(email)
                classified = True
            if 'situational' in bundle_name:
                group_map[grouping_id]['Situational'].add(email)
                classified = True
            if 'inform' in bundle_name or 'information' in bundle_name:
                group_map[grouping_id]['Inform'].add(email)
                classified = True

            # Track explicit Main rows when source data contains them.
            if not classified or 'main' in bundle_name:
                group_map[grouping_id]['Main'].add(email)
    else:
        for _, row in df.iterrows():
            mail = row['MemberMail']
            upn  = row['MemberUPN']
            # Prefer MemberMail; fall back to MemberUPN when mail is absent or a noreply address.
            email = mail if (mail and "noreply" not in str(mail)) else upn
            if not email or "noreply" in str(email):
                continue
            # For bundle classification, only use the email if it is a real (non-noreply) address.
            # When MemberMail is noreply and we fell back to UPN, restrict to Main-only (admin
            # service accounts present in every DL should not inflate Standing/Situational/Inform).
            mail_is_noreply = mail and "noreply" in str(mail)
            
            grouping_id = row['GroupingID']
            group_name = str(row['GroupName']).lower()
            classified = False
            
            # Try to classify based on keywords.
            # Skip Standing/Situational/Inform for noreply-fallback accounts — service accounts
            # present in every DL must not inflate those bundle counts.
            if not mail_is_noreply:
                if 'standing' in group_name:
                    group_map[grouping_id]['Standing'].add(email)
                    classified = True
                if 'situational' in group_name:
                    group_map[grouping_id]['Situational'].add(email)
                    classified = True
                if 'inform' in group_name or 'information' in group_name:
                    group_map[grouping_id]['Inform'].add(email)
                    classified = True
            
            # Rows without standing/situational/inform keywords are treated as Main.
            # noreply-fallback accounts are also counted here (they represent real DL members).
            if not classified:
                group_map[grouping_id]['Main'].add(email)
    
    return group_map


def resolve_validation_file(data_dir: Path) -> Path:
    """Resolve O365 extracted file for validation, preferring fixed name then latest *_updated.xlsx."""
    fixed = data_dir / "0365_0311_updated.xlsx"
    if fixed.exists():
        return fixed

    candidates = [
        p for p in data_dir.glob("*_updated.xlsx")
        if "membership_validation_report" not in p.name.lower()
        and "teamsrc" not in p.name.lower()
    ]
    if not candidates:
        raise FileNotFoundError(
            "No O365 extracted file found. Run scripts/extract.py first to generate *_updated.xlsx"
        )

    return max(candidates, key=lambda p: p.stat().st_mtime)

def main():
    try:
        setup_logging()
        env_map = load_env_file()
        data_dir = resolve_data_dir(env_map)
        root_data_dir = resolve_root_data_dir(env_map)

        master_file = resolve_master_file(
            data_dir,
            root_data_dir,
            env_value("MASTER_FILE", "TeamSrc31326.xlsx", env_map),
        )

        configured_validation = env_value("VALIDATION_FILE", "", env_map)
        if configured_validation:
            validation_path = Path(configured_validation)
            validation_file = validation_path if validation_path.is_absolute() else data_dir / validation_path
        else:
            validation_file = resolve_validation_file(data_dir)

        report_file = data_dir / env_value("REPORT_FILE", "Membership_Validation_Report.xlsx", env_map)

        if not master_file.exists():
            raise FileNotFoundError(f"Master file not found: {master_file}")
        if not validation_file.exists():
            raise FileNotFoundError(f"Validation file not found: {validation_file}")

        # === 1. Load and Normalize Data ===
        df_master = load_and_normalize(master_file, is_master=True)
        df_validation = load_and_normalize(validation_file)
        
        
        # === 2. Build Membership Maps ===
        master_map = build_membership_maps(df_master, is_master=True)
        validation_map = build_membership_maps(df_validation)
        irdt_master_map, irdt_validation_map, irdt_expected_dl_map = build_irdt_maps(
            df_master,
            df_validation,
        )
        
        
        # === 3. Generate Comparison Report ===
        master_group_details = (
            df_master
            .drop_duplicates(subset=['GroupingID'])
            .set_index('GroupingID')[['GroupName', 'SchemaID']]
            .to_dict('index')
        )
        val_group_names = (
            df_validation
            .drop_duplicates(subset=['GroupingID'])
            .set_index('GroupingID')['GroupName']
            .to_dict()
        )

        results = []
        missing_groups = []
        for group_id in master_map:
            schema_id = master_group_details[group_id]['SchemaID']
            if normalize_schema_id(schema_id) == IRDT_SCHEMA_ID:
                expected_dls = irdt_expected_dl_map.get(group_id, {})
                master_bundles = irdt_master_map.get(group_id, {})
                validation_bundles = irdt_validation_map.get(group_id, {})

                missing_entries = []
                extra_entries = []
                irdt_result = {
                    'GroupingID': group_id,
                    'GroupNameSrc': master_group_details[group_id]['GroupName'],
                    'GroupName0365': '; '.join(sorted(expected_dls.values())),
                    'NameMismatch': 'NO',
                    'SchemaID': schema_id,
                    'TeamSrc_Standing': '',
                    'TeamSrc_Situational': '',
                    'TeamSrc_Inform': '',
                    'TeamSrc_Main': '',
                    'O365_Standing': '',
                    'O365_Situational': '',
                    'O365_Inform': '',
                    'O365_Main': '',
                    'MissingMain': 'None',
                    'ExtraMain': 'None',
                    'MissingInform': 'None',
                    'ExtraInform': 'None',
                    'ExtraStandingOnly': 'None',
                    'ExtraSituationalOnly': 'None',
                    'ExtraInBothBundles': 'None',
                    'ExistsInBothBundles': 'None',
                }

                has_issues = False
                for bundle_key, _ in IRDT_BUNDLES.values():
                    source_members = master_bundles.get(bundle_key, set())
                    o365_members = validation_bundles.get(bundle_key, set())
                    missing_members = source_members - o365_members
                    extra_members = o365_members - source_members

                    irdt_result[f'ExpectedDL_{bundle_key}'] = expected_dls.get(bundle_key, '')
                    irdt_result[f'TeamSrc_{bundle_key}'] = len(source_members)
                    irdt_result[f'O365_{bundle_key}'] = len(o365_members)
                    irdt_result[f'Missing_{bundle_key}'] = (
                        '; '.join(sorted(missing_members)) if missing_members else 'None'
                    )
                    irdt_result[f'Extra_{bundle_key}'] = (
                        '; '.join(sorted(extra_members)) if extra_members else 'None'
                    )

                    missing_entries.extend(
                        f'{email} ({bundle_key})' for email in sorted(missing_members)
                    )
                    extra_entries.extend(
                        f'{email} ({bundle_key})' for email in sorted(extra_members)
                    )
                    has_issues = has_issues or bool(missing_members or extra_members)

                irdt_result['MissingInDL'] = '; '.join(missing_entries) if missing_entries else 'None'
                irdt_result['ExtraInDL'] = '; '.join(extra_entries) if extra_entries else 'None'
                irdt_result['Notes'] = '' if has_issues else 'OK'
                results.append(irdt_result)
                continue

            if group_id not in validation_map:
                logging.warning(f"Group ID {group_id} found in master but not in validation data")
                missing_groups.append(group_id)
                continue
                
            # Get members from both sources
            master_standing = master_map[group_id]['Standing']
            master_situational = master_map[group_id]['Situational']
            master_inform = master_map[group_id]['Inform']
            
            val_standing = validation_map[group_id]['Standing']
            val_situational = validation_map[group_id]['Situational']
            val_inform = validation_map[group_id]['Inform']
            val_main_explicit = validation_map[group_id]['Main']

            # Team source Main is derived as Standing U Situational.
            main_master = master_standing | master_situational

            # Prefer explicit O365 Main membership when available; fall back to legacy union.
            main_validation = val_main_explicit if val_main_explicit else (val_standing | val_situational)
            
            # Find discrepancies
            missing_standing = master_standing - val_standing
            missing_situational = master_situational - val_situational
            missing_inform = master_inform - val_inform
            missing_main = main_master - main_validation
            
            extra_standing = val_standing - master_standing
            extra_situational = val_situational - master_situational
            extra_inform = val_inform - master_inform
            extra_main = main_validation - main_master
            
            in_both_bundles = val_standing & val_situational
            
            
            # NEW: Track users who are extra in only one bundle type
            extra_standing_only = extra_standing - extra_situational
            extra_situational_only = extra_situational - extra_standing
            extra_in_both = extra_standing & extra_situational
            
            # Format results with more detailed categorization
            missing = []
            if missing_standing:
                missing.extend([f"{email} (Standing)" for email in sorted(missing_standing)])
            if missing_situational:
                missing.extend([f"{email} (Situational)" for email in sorted(missing_situational)])
            if missing_inform:
                missing.extend([f"{email} (Inform)" for email in sorted(missing_inform)])
            
            # More detailed extra categorization
            extra_standing_list = [f"{email} (Standing only)" for email in sorted(extra_standing_only)]
            extra_situational_list = [f"{email} (Situational only)" for email in sorted(extra_situational_only)]
            extra_both_list = [f"{email} (Both bundles)" for email in sorted(extra_in_both)]
            extra_inform_list = [f"{email} (Inform)" for email in sorted(extra_inform)]
            extra_main_list = [f"{email} (Main)" for email in sorted(extra_main)]
            
            # Combine all extra users (Main is already captured in ExtraMain column)
            all_extra = extra_standing_list + extra_situational_list + extra_both_list + extra_inform_list
            
            # Get group names
            try:
                group_name_src = master_group_details[group_id]['GroupName']
                group_name_val = val_group_names[group_id]
                schema_id = master_group_details[group_id]['SchemaID']
            except KeyError:
                logging.warning(f"Could not find details for Group ID {group_id}")
                continue
            
            # Determine if there are any issues
            has_issues = (len(missing_standing) > 0 or 
                         len(missing_situational) > 0 or 
                         len(missing_inform) > 0 or
                         len(missing_main) > 0 or
                         len(extra_standing) > 0 or 
                         len(extra_situational) > 0 or
                         len(extra_inform) > 0 or
                         len(extra_main) > 0 or
                         group_name_src.lower() != group_name_val.lower())
            
            results.append({
                'GroupingID': group_id,
                'GroupNameSrc': group_name_src,
                'GroupName0365': group_name_val,
                'NameMismatch': 'YES' if group_name_src.lower() != group_name_val.lower() else 'NO',
                'SchemaID': schema_id,
                'TeamSrc_Standing': len(master_standing),
                'TeamSrc_Situational': len(master_situational),
                'TeamSrc_Inform': len(master_inform),
                'TeamSrc_Main': len(main_master),
                'O365_Standing': len(val_standing),
                'O365_Situational': len(val_situational),
                'O365_Inform': len(val_inform),
                'O365_Main': len(main_validation),
                'MissingInDL': "; ".join(missing) if missing else "None",
                'ExtraInDL': "; ".join(all_extra) if all_extra else "None",
                'MissingMain': "; ".join(sorted(missing_main)) if missing_main else "None",
                'ExtraMain': "; ".join(sorted(extra_main)) if extra_main else "None",
                'MissingInform': "; ".join(sorted(missing_inform)) if missing_inform else "None",
                'ExtraInform': "; ".join(sorted(extra_inform)) if extra_inform else "None",
                'ExtraStandingOnly': "; ".join(sorted(extra_standing_only)) if extra_standing_only else "None",
                'ExtraSituationalOnly': "; ".join(sorted(extra_situational_only)) if extra_situational_only else "None",
                'ExtraInBothBundles': "; ".join(sorted(extra_in_both)) if extra_in_both else "None",
                'ExistsInBothBundles': "; ".join(sorted(in_both_bundles)) if in_both_bundles else "None",
                'Notes': 'OK' if not has_issues else ''
            })
        
        # === 4. Create Output ===
        output_df = pd.DataFrame(results)
        is_irdt_result = output_df['SchemaID'].map(normalize_schema_id).eq(IRDT_SCHEMA_ID)
        legacy_results_df = output_df.loc[~is_irdt_result].copy()
        irdt_results_df = output_df.loc[is_irdt_result].copy()
        
        # Add summary statistics
        total_groups = len(results)
        ok_groups = len([r for r in results if r['Notes'] == 'OK'])
        
        metadata_df = pd.DataFrame([
            {"Metric": "RunTimestamp", "Value": datetime.now().isoformat(timespec="seconds")},
            {"Metric": "MasterFile", "Value": str(master_file)},
            {"Metric": "ValidationFile", "Value": str(validation_file)},
            {"Metric": "ReportFile", "Value": str(report_file)},
            {"Metric": "TotalGroupsProcessed", "Value": total_groups},
            {"Metric": "GroupsWithNoDiscrepancies", "Value": ok_groups},
            {"Metric": "GroupsMissingInValidation", "Value": len(missing_groups)},
        ])

        legacy_issues_df = legacy_results_df[legacy_results_df['Notes'] != 'OK'].copy()
        irdt_issues_df = irdt_results_df[irdt_results_df['Notes'] != 'OK'].copy()

        green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        def _format_sheet(ws):
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            notes_col_idx = next(
                (cell.column for cell in ws[1] if cell.value == 'Notes'),
                None,
            )
            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", wrap_text=True)
            for row in ws.iter_rows(min_row=2):
                fill = green_fill if notes_col_idx and row[notes_col_idx - 1].value == 'OK' else red_fill
                for cell in row:
                    cell.fill = fill
            for col in ws.columns:
                col_letter = get_column_letter(col[0].column)
                max_len = max(
                    (len(str(c.value)) for c in col if c.value is not None),
                    default=10,
                )
                ws.column_dimensions[col_letter].width = min(max_len + 2, 55)

        with pd.ExcelWriter(report_file, engine="openpyxl") as writer:
            legacy_results_df.to_excel(writer, index=False, sheet_name="Results")
            legacy_issues_df.to_excel(writer, index=False, sheet_name="Issues Only")
            irdt_results_df.to_excel(writer, index=False, sheet_name="IRDT Results")
            irdt_issues_df.to_excel(writer, index=False, sheet_name="IRDT Issues")
            metadata_df.to_excel(writer, index=False, sheet_name="Metadata")
            _format_sheet(writer.sheets["Results"])
            _format_sheet(writer.sheets["Issues Only"])
            _format_sheet(writer.sheets["IRDT Results"])
            _format_sheet(writer.sheets["IRDT Issues"])
        
        print(f"Validation report generated successfully!")
        print(f"Processed {total_groups} groups, {ok_groups} with no discrepancies")
        print(f"Report path: {report_file}")
        
    except Exception as e:
        logging.error(f"Error in main process: {str(e)}")
        raise

if __name__ == "__main__":
    main()