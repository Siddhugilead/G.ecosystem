import argparse
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
EXTRACT_SCRIPT = SCRIPT_DIR / "extract.py"
VALIDATE_SCRIPT = SCRIPT_DIR / "validate.py"


def load_env_file() -> dict[str, str]:
    """Load key=value pairs from .env (workspace root or script folder)."""
    candidates = [SCRIPT_DIR.parent / ".env", SCRIPT_DIR / ".env"]
    env_map: dict[str, str] = {}
    for env_path in candidates:
        if not env_path.exists():
            continue
        for line in env_path.read_text(encoding="utf-8").splitlines():
            raw = line.strip()
            if not raw or raw.startswith("#") or "=" not in raw:
                continue
            key, value = raw.split("=", 1)
            env_map[key.strip()] = value.strip().strip('"').strip("'")
        break
    return env_map


def env_value(name: str, default: str, env_map: dict[str, str]) -> str:
    return os.getenv(name, env_map.get(name, default))


def is_mmdd_folder_name(name: str) -> bool:
    """True when folder name looks like MDD or MMDD and is a valid month/day."""
    if not name.isdigit() or len(name) not in (3, 4):
        return False

    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    if month < 1 or month > 12:
        return False
    if day < 1 or day > 31:
        return False

    try:
        datetime(datetime.now().year, month, day)
    except ValueError:
        return False
    return True


def mmdd_sort_key(name: str) -> tuple[int, int]:
    month_digits = 1 if len(name) == 3 else 2
    month = int(name[:month_digits])
    day = int(name[month_digits:])
    return month, day


def resolve_data_dir(env_map: dict[str, str]) -> Path:
    configured = env_value("DATA_DIR", "excel_files", env_map)
    candidate = Path(configured)
    if candidate.is_absolute():
        root_data_dir = candidate
    else:
        local = SCRIPT_DIR / configured
        root_data_dir = local if local.exists() else SCRIPT_DIR.parent / configured

    daily_folder = env_value("DAILY_FOLDER", "", env_map).strip()
    if daily_folder:
        forced_dir = root_data_dir / daily_folder
        if not forced_dir.exists():
            raise FileNotFoundError(f"DAILY_FOLDER not found under DATA_DIR: {forced_dir}")
        return forced_dir

    if not root_data_dir.exists() or not root_data_dir.is_dir():
        return root_data_dir

    dated_dirs = [
        p for p in root_data_dir.iterdir()
        if p.is_dir() and is_mmdd_folder_name(p.name)
    ]
    if not dated_dirs:
        return root_data_dir

    # Pick the latest day folder by MMDD value.
    return max(dated_dirs, key=lambda p: mmdd_sort_key(p.name))


def resolve_member_path_for_archive(data_dir: Path, env_map: dict[str, str]) -> Path | None:
    member_name = env_value("MEMBER_LIST_FILE", "", env_map)
    if member_name:
        member_path = Path(member_name)
        if not member_path.is_absolute():
            member_path = data_dir / member_path
        if member_path.exists():
            return member_path

    csv_candidates = sorted(data_dir.glob("MembersList_*.csv"))
    if csv_candidates:
        return csv_candidates[-1]

    xlsx_candidates = sorted(data_dir.glob("MembersList_*.xlsx"))
    if xlsx_candidates:
        return xlsx_candidates[-1]

    return None


def archive_processed_files() -> None:
    """Archive processed member-list files after successful FinalReport."""
    # Archiving disabled - files remain in the same folder
    print("Files retained in current folder (archiving disabled)")


def run_script(script_path: Path) -> int:
    """Run a python script with the current interpreter and stream output."""
    print(f"\nRunning: {script_path.name}")
    result = subprocess.run([sys.executable, str(script_path)], check=False)
    return result.returncode


def run_extract() -> int:
    return run_script(EXTRACT_SCRIPT)


def run_validate() -> int:
    return run_script(VALIDATE_SCRIPT)


def run_full(archive_on_success: bool = True) -> int:
    extract_code = run_extract()
    if extract_code != 0:
        print("Extract failed. Skipping validate.")
        return extract_code
    validate_code = run_validate()
    if validate_code == 0 and archive_on_success:
        archive_processed_files()
    return validate_code


def handle_action(action: str, archive_on_success: bool = True) -> int:
    action_key = action.strip().lower()
    if action_key == "extract":
        return run_extract()
    if action_key == "validate":
        return run_validate()
    if action_key in {"completevalidate", "full", "finalreport"}:
        return run_full(archive_on_success=archive_on_success)

    print(f"Unknown action: {action}")
    return 1


def prompt_action() -> str:
    print("\nSelect an option:")
    print("1. Extract")
    print("2. Validate")
    print("3. FinalReport")

    choice = input("Enter choice (1/2/3): ").strip()
    mapping = {
        "1": "extract",
        "2": "validate",
        "3": "finalreport",
    }
    return mapping.get(choice, "")


def main() -> None:
    parser = argparse.ArgumentParser(description="Daily validation menu")
    parser.add_argument(
        "--action",
        choices=["extract", "validate", "completevalidate", "full", "finalreport"],
        help="Run without menu prompt",
    )
    parser.add_argument(
        "--no-archive",
        action="store_true",
        help="Skip archive step after successful FinalReport",
    )
    args = parser.parse_args()

    action = args.action if args.action else prompt_action()
    if not action:
        print("Invalid menu choice.")
        sys.exit(1)

    exit_code = handle_action(action, archive_on_success=not args.no_archive)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
