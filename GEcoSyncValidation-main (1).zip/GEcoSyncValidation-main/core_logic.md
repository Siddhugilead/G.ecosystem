# Core Logic Overview

This document summarizes the main logic in:
- `scripts/extract.py`
- `scripts/validate.py`

## 1) `extract.py` Core Logic

### Purpose
Prepare an O365 export file by extracting `GroupingID`, removing invalid rows, and adding an `ExistsInAll3` indicator.

### Input
- Excel file (passed via `--file`, or first `.xlsx` in current folder)
- Default processing starts at row 2 (`--start-row 2`)

### Main Steps
1. Load the workbook with `header=None` to preserve original structure.
2. Ensure column G (index `6`) exists.
3. Set header text in row 1 for column G as `GroupingID`.
4. From `start_row` onward:
- Normalize description text to lowercase.
- Extract numeric `GroupingID` from patterns like:
  - `grouping: 1234`
  - `groupingid: 1234`
  - `(1234)`
  - `roster members 1234`
5. Remove rows where `GroupingID` is blank.
6. Classify group type from group email:
- contains `-standing@` -> `Standing`
- contains `-situational@` -> `Situational`
- contains `@` -> `Main`
7. Build a presence map keyed by `(GroupingID, MemberUPN)` and collect all seen types.
8. Set `ExistsInAll3`:
- `Yes` when all three types exist: `Main`, `Standing`, `Situational`
- `No` otherwise
9. Rebuild output with top rows preserved and filtered rows appended.
10. Save to `<input_stem>_updated.xlsx` in the same folder.

### Output
- Updated Excel file with:
- `GroupingID` in column G
- `ExistsInAll3` as a new column
- Rows with blank `GroupingID` deleted

## 2) `validate.py` Core Logic

### Purpose
Compare membership from source (`TeamSrc`) vs O365 validation file and generate discrepancy report.

### Input Files
- Master source of truth: `excel_files/TeamSrc31326.xlsx`
- Validation source: `excel_files/0365_0311_updated.xlsx`

### Header Standardization (Master)
Before comparisons, master headers are renamed:
- `TeamRosterDisplayName` -> `GroupName`
- `UserName` -> `MemberName`
- `Email` -> `MemberMail`

### Normalization
1. Validate required columns exist (fail fast with clear error if missing).
2. Normalize emails:
- lowercase + trim
- `@gc.com` converted to `@gilead.com`
3. Normalize `GroupingID` as stripped string.

### Membership Map Building
For each `GroupingID`, build three sets:
- `Standing`
- `Situational`
- `Inform`

Master map rules:
- `BundleName` contains `standing` -> `Standing`
- `BundleName` contains `situational` -> `Situational`
- `BundleName` contains `inform` or `information` -> `Inform`

Validation map rules:
- use `MemberMail`; if blank, fallback to `MemberUPN`
- infer bundle from `GroupName` containing `standing`, `situational`, or `inform/information`

Rows with empty email or `noreply` are skipped.

### Comparison Logic per Group
For each `GroupingID` in master map (if present in validation map):
1. Compare standing, situational, and inform sets.
2. Derive Main as a union:
- `main_master = standing_master U situational_master`
- `main_validation = standing_val U situational_val`
3. Compare `main_master` vs `main_validation`.
2. Compute:
- Missing in DL (`master - validation`)
- Extra in DL (`validation - master`)
- Users present in both validation bundles
3. Split extras into:
- `ExtraStandingOnly`
- `ExtraSituationalOnly`
- `ExtraInBothBundles`
4. Compare group names (`GroupNameSrc` vs `GroupName0365`) for mismatch.
5. Mark `Notes = 'OK'` only if no discrepancies (standing/situational/inform/main) and no name mismatch.

### Output
- `Membership_Validation_Report.xlsx`
- Includes counts, missing/extra users, bundle overlap, name mismatch, and notes.

## 3) SchemaID 38: IRDT Logic

`SchemaID` is read from the TeamSource workbook only. O365 exports remain schema-independent.

For each TeamSource roster with `SchemaID` `38`:
1. Normalize `GroupName` and use it as the roster name/stem.
2. Require that the normalized roster stem maps to only one `GroupingID` within SchemaID 38.
3. Map the normalized `BundleName` to an IRDT suffix:
  - `Core Working Group` -> `CoreWG`
  - `Strategic Framework Working Group` -> `StrategicWG`
  - `Data Needs Working Group` -> `DataWG`
  - `IRWG Standing` -> `IRWG-Standing`
  - `IRWG Situational` -> `IRWG-Situational`
  - `DGS Editor` -> `DGS`
4. Normalize the roster name to the O365 stem: slashes and spaces become hyphens, while parentheses are removed. Then construct each expected DL as `<roster stem>-<suffix>@gilead.com`.
5. Match O365 `GroupName` values to either the DL display name (`<roster stem>-<suffix>`) or full email address after normalization. Ignore `noreply` service accounts, then compare member sets independently for all six bundles.

SchemaID 38 does not derive a `Main` membership set and does not apply legacy bundle-overlap checks. Non-38 schemas retain the legacy Standing, Situational, Inform, and Main logic.

## Quick Run Commands
```powershell
py .\scripts\extract.py --file ".\excel_files\0365_0311.xlsx" --start-row 2
py .\scripts\validate.py
```
