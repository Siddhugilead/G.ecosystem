# GEcoSync Daily Validation

## Purpose
Daily workflow to:
1. Extract Grouping information from O365 members list.
2. Validate O365 vs Team source-of-truth.
3. Generate final membership report.

## Folder Layout
- `excel_files/`: input and output files
- `excel_files/MMDD/`: optional daily drop folders (example: `excel_files/316/`)
- `scripts/extract.py`: extraction script
- `scripts/validate.py`: validation script
- `scripts/menu.py`: interactive runner
- `.env`: daily configurable file names

## Daily Folder Resolution
- By default, scripts auto-pick the most recently updated folder under `excel_files/` whose name is `MDD` or `MMDD` (example: `316`, `0316`).
- If no such folder exists, scripts use `excel_files/` directly.
- To force a specific day folder, set `DAILY_FOLDER` in `.env`.
- `MEMBER_LIST_FILE` is optional for extract/archive when a `MembersList_*.csv` or `MembersList_*.xlsx` exists in the resolved folder.
- `MASTER_FILE` is checked in the resolved day folder first, then in the root `excel_files/` folder. If missing, latest `TeamSrc*.xlsx` is auto-selected.

## Daily Steps
1. Update `.env` values:
- `MEMBER_LIST_FILE`
- `MASTER_FILE`
- `REPORT_FILE`
- Optional: `DAILY_FOLDER` (for example, `316`)
2. Run menu:
```powershell
py .\scripts\menu.py
```
3. Choose one:
- `1` Extract
- `2` Validate
- `3` FinalReport (Extract + Validate)

## Direct Commands
```powershell
py .\scripts\extract.py
py .\scripts\validate.py
py .\scripts\menu.py --action finalreport
```

## Environment Setup
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Logs
Run logs are saved to `logs/run_YYYYMMDD.log`.

## FinalReport Archiving
`FinalReport` archives processed member-list files into:
- `<resolved_data_dir>/archive/YYYYMMDD_HHMMSS/`

When daily folders are used, archive is created inside that folder (example: `excel_files/316/archive/...`).

Use this to run FinalReport without archiving:
```powershell
py .\scripts\menu.py --action finalreport --no-archive
```

## Report Sheets
Generated report contains:
- `Results` (legacy schemas)
- `Issues Only` (legacy-schema discrepancies)
- `IRDT Results` (SchemaID 38 rosters)
- `IRDT Issues` (SchemaID 38 discrepancies)
- `Metadata` (run timestamp, input/output paths, summary counts)

## SchemaID 38: IRDT Roster Validation
- `SchemaID` is required only in the TeamSource workbook. O365 member-list exports do not need a schema column.
- For every TeamSource roster with `SchemaID` `38`, `GroupName` is used as the roster stem and must be unique within SchemaID 38.
- TeamSource `BundleName` values map to these exact O365 distribution lists:
	- `Core Working Group` -> `<Roster name>-CoreWG@gilead.com`
	- `Strategic Framework Working Group` -> `<Roster name>-StrategicWG@gilead.com`
	- `Data Needs Working Group` -> `<Roster name>-DataWG@gilead.com`
	- `IRWG Standing` -> `<Roster name>-IRWG-Standing@gilead.com`
	- `IRWG Situational` -> `<Roster name>-IRWG-Situational@gilead.com`
	- `DGS Editor` -> `<Roster name>-DGS@gilead.com`
	- O365 may provide either the DL display name (for example, `BIC-LEN-IRWG-Standing`) or its email-form name. TeamSource slashes, including spaced slashes, and spaces normalize to one hyphen; parentheses are removed: `BIC/LEN` and `ISL / LEN` both become `BIC-LEN`/`ISL-LEN`, and `LEN for Prevention (L4P)` becomes `LEN-for-Prevention-L4P`.
	- The report compares missing and extra members independently for each of the six lists and excludes O365 `noreply` service accounts. Legacy schemas continue to use the existing Standing, Situational, Inform, and Main validation.

## Smoke Test
```powershell
py .\scripts\smoke_test.py
```
Checks:
- `.env` keys
- input file existence
- script files existence
